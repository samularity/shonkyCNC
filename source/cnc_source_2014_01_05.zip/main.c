/*
 * Created: 30.10.2013 22:08:51
 *  Author: Samuel Munz
 */ 

/*////////////////////////////////////////////////////////////////////////////////////////////////////////
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

PinOut TinyMega :	http://shackspace.de/wiki/doku.php?id=project:tinymega
UART-Display :		http://shackspace.de/wiki/doku.php?id=52x_20x2_x_7x5_dot-matrix_vfd

F0:		Puls Zeit					�ber 1k - 10k poti 
F1:		Kondesator Spannung			�ber 7/1 Spannungsteiler 40V => 35V/5V Schutz mit 5,1V Z_Diode
D0:		Eingang Ladetaster			schlie�er nach gnd			
D1:		Eingang Entladung			?�ffner nach gnd
C7:		PWM out						reserviert f�r erweiterung
D5:		Lade Kondensator			Schaltet Mosfet zum Kondensatorbank Laden
D3:		Seriell_TX					Sendet daten ans Display
B0-B7:	Entlade Kondesnator			Sendet High zum Kondensatorbank entladen, sost low (�ber mosfet ?)
E6:		Debug-LED					onboard
Vref:	Vref=5V extern				Mit Vcc verbinden und �ber 50nF mit Masse

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
/*/////////////////////////////////////////////////////////////////////////////////////////////////////////



#include "main.h"

int main(void)
{
	clock_prescale_set(clock_div_1);	//clock prescaler auf  1 =>  16MHz
	MCUCR = (1 << JTD);					//jtag ausschalten
	
	DDRE|=(1 << PE6);
	DDRB = 0xff;//alle als ausgang
	adc_init();	//external_vref // siehe adc.h
	usb_init(); 
	timer_init();
	sleep_ms(250);
	readADC(0);//muss sein um einma ch0 auszuw�hlen		

    while(1)   
	{
						
///////////////////  TEST  //////////////////////////////////////////////////////////////////////////////////////
			
	if (usb_serial_available())
	{
		char input =usb_serial_getchar();
		//usb_serial_putchar(input);
		usb_serial_flush_input();
		
		switch (input)
		{
		case 27: //escape -> bootloader
			usb_send_str((unsigned char *)"\r\n\t BOOTLOADER");
			bootloader();
			break;
			
		case 'w':		
			stepper_x_move(1);//1 step vor
			usb_serial_putchar('^');
			break;
		
		case 's':
			stepper_x_move(-1);//1 step zur�ck
			usb_serial_putchar('v');
			break;
		
		case 'r':	//114=r  ^=94
				stepper_x_move(200);//200 steps vor (1 umdrehung)
				usb_send_str("(^ 200)");
				break;
		
		case 'f':  //102=f v=118
			stepper_x_move(-200);//200 step zur�ckr (1umdrehung)
			usb_send_str("(v 200)");
			break;
			
			
		case 'd':		
			stepper_y_move(1);//1 step vor
			usb_serial_putchar('<');
			break;
		
		case 'a':	
			stepper_y_move(-1);//1 step zur�ck
			usb_serial_putchar('>');
			break;			
			
			
		case 'q':  
			stepper_y_move(200);//200 step zur�ckr (1umdrehung)
			usb_send_str("(< 200)");
			break;	
			
		case 'e':  
			stepper_y_move(-200);//200 step zur�ckr (1umdrehung)
			usb_send_str("(> 200)");
			break;	
			
			
			
			
			
		case 'p':
			stepper_x_move(200);
			stepper_y_move(200);
			usb_send_str("p okay\r\n");	
			break;
			
		default:      // Anweisungen wenn keine der oben definierten Bedingungen erf�llt ist
			break;
		}
		
		
		/*
		if (input==115) //
		{
			usb_send_str((unsigned char *)"\r\n\t clk / 256");
			TCCR1B=0;
			TCCR1B = (1 << WGM12) | (1 << CS12); //prescaler und ctc mode = clk/256
		}

		if (input==116) //t
		{
			usb_send_str((unsigned char *)"\r\n\t  clk /  8");
			TCCR1B=0;
			TCCR1B = (1 << WGM12) | (1 << CS11)| (1 << CS10);//  TCCR1B Prescaler = clk/8, CTC mode
		}

		if (input==117)//u
		{
			usb_send_str((unsigned char *)"\r\n\t clk /  1");
			TCCR1B=0;
			TCCR1B = (1 << WGM12) | (1 << CS10); //prescaler und ctc mode = clk/1
		}
		
		
		if (input==118)//v
		{
			usb_send_str((unsigned char *)"\r\n\t OCR1A = ");
			uint16_t tmp = readADC(0);
			OCR1A = tmp;
			usb_send_int(tmp);
		}
		
		*/
	
		
	}			
				
				
//////////////  TEST ENDE   ///////////////////////////////////////////////////////////////////////////////////////////
					
    }
}




void sleep_us(uint16_t us){
	while(us){
		us--;
		_delay_us(1);
	}
}

void sleep_ms(uint16_t ms){
	while(ms){
		ms--;
		_delay_ms(1);
	}
}

void bootloader (void)
{
	MCUCR  |=  (1 << IVCE);  //IVCE  = 1		//register f�r restret
	MCUCR  |=  (1 << IVSEL); //IVSEL = 1		//register f�r restret
	TIMSK0 = 0;             //Timer-Interrupt ausschalten
	TIMSK1 = 0;				//noch ein Timer-Interrupt ausschalten
	sleep_ms(500);
	asm volatile ("jmp 0x3800");
}

void serial_bootloader_handler(void)
{
  if (usb_serial_available())
	{
		char input =usb_serial_getchar();
		usb_serial_putchar(input);
		usb_serial_flush_input();
		
		if (input==27)
		{
			usb_send_str((unsigned char *)"\r\n\t BOOTLOADER");
			bootloader();
		}
			
		
		if (input==115)
		{
			usb_send_str((unsigned char *)"\r\n\t clk / 256");
			TCCR1B=0;
			TCCR1B = (1 << WGM12) | (1 << CS12); //prescaler und ctc mode = clk/256
		}
		
		if (input==116)
		{
			usb_send_str((unsigned char *)"\r\n\t  clk /  8");
			TCCR1B=0;
			TCCR1B = (1 << WGM12) | (1 << CS11)| (1 << CS10);//  TCCR1B Prescaler = clk/8, CTC mode
		}		

		if (input==117)
		{
			usb_send_str((unsigned char *)"\r\n\t clk /  1");
			TCCR1B=0;
			TCCR1B = (1 << WGM12) | (1 << CS10); //prescaler und ctc mode = clk/1
		}
	}	
}


